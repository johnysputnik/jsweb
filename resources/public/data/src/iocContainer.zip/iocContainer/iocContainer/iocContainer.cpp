// iocContainer.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <memory>
#include <map>
#include <functional>
#include <iostream>
#include <string>


class One
{
public:
    One(){}
    virtual ~One(){}
    std::string getOutput() const {  return message_;  }
    std::string message_;
};
typedef std::shared_ptr<One> OnePtr;

class Two
{
public:
    Two(){}
    virtual ~Two(){}
    std::string getOutput() const {  return message_;  }
    std::string message_;
};
typedef std::shared_ptr<Two> TwoPtr;

class Three
{
public:
    Three(){}
    virtual ~Three(){}
    std::string getOutput() const {  return "IOC Created";  }
};
typedef std::shared_ptr<Three> ThreePtr;


class DependentClass
{
public:
    DependentClass(OnePtr one, TwoPtr two, ThreePtr three) : one_(one), two_(two), three_(three){}
    void output() const 
    { 
        std::cout << "done it" << std::endl; 
        std::cout << "one - " << one_->getOutput() << std::endl; 
        std::cout << "two - " << two_->getOutput() << std::endl; 
        std::cout << "three - " << three_->getOutput() << std::endl; 
    
    }
private:
    DependentClass(){}
    OnePtr one_;
    TwoPtr two_;
    ThreePtr three_;
};
typedef std::shared_ptr<DependentClass> DependentClassPtr;



class IOCContainer
{
private:
    class IHolder
    {
    public:
        virtual void noop(){}
    };

    template<class T>
    class Holder : public IHolder
    {
    public:
        std::shared_ptr<T> instance_;
    };

    std::map<std::string, std::function<void*()>> creatorMap_;
    std::map<std::string, std::shared_ptr<IHolder>> instanceMap_;

public:

    template <class T, typename... Ts>
    void RegisterSingletonClass()
    {
        std::shared_ptr<Holder<T>> holder(new Holder<T>());
        holder->instance_ = std::shared_ptr<T>(new T(GetInstance<Ts>()...));

        instanceMap_[typeid(T).name()] = holder;
    }

    template <class T>
    void RegisterInstance(std::shared_ptr<T> instance)
    {
        std::shared_ptr<Holder<T>> holder(new Holder<T>());
        holder->instance_ = instance;

        instanceMap_[typeid(T).name()] = holder;
    }


    template <class T, typename... Ts>
    void RegisterClass()
    {
        auto createType = [this]() -> T * {
            return new T(GetInstance<Ts>()...);
        };

        creatorMap_[typeid(T).name()] = createType;
    }

    template <class T>
    std::shared_ptr<T> GetInstance()
    {
        if(instanceMap_.find(typeid(T).name()) != instanceMap_.end())
        {
            std::shared_ptr<IHolder> iholder = instanceMap_[typeid(T).name()];
            
            Holder<T> * holder = dynamic_cast<Holder<T>*>(iholder.get());
            return holder->instance_;
        }
        else
        {
            return std::shared_ptr<T>(static_cast<T*>(creatorMap_[typeid(T).name()]()));
        }
    }

};

int main(int argc, char* argv[])
{
    IOCContainer container;

    container.RegisterSingletonClass<One>();
    OnePtr one = container.GetInstance<One>();
    one->message_ = "Singleton";

    TwoPtr two(new Two());
    two->message_ = "Registered Instance";
    container.RegisterInstance<Two>(two);

    container.RegisterClass<Three>();
    container.RegisterClass<DependentClass, One, Two, Three>();

    DependentClassPtr instance = container.GetInstance<DependentClass>();

    instance->output();
}

